import { createClient } from "@supabase/supabase-js";

export const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

export type Material = {
  id: string;
  title: string;
  description: string | null;
  university: string;
  faculty: string;
  subject: string;
  type: "qeyd" | "imtahan" | "xulase" | "test";
  file_path: string;
  file_name: string;
  downloads: number;
  created_at: string;
};

export const TYPE_LABELS: Record<Material["type"], string> = {
  qeyd: "Mühazirə qeydi",
  imtahan: "Keçmiş imtahan",
  xulase: "Mövzu xülasəsi",
  test: "Sınaq testi",
};
