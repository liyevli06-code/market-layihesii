import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

// Hər dəfə təzə işləsin, keş olunmasın
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  // CRON_SECRET təyin olunubsa, yalnız Vercel Cron çağıra bilər
  const secret = process.env.CRON_SECRET;
  if (secret && req.headers.get("authorization") !== `Bearer ${secret}`) {
    return NextResponse.json({ ok: false, error: "unauthorized" }, { status: 401 });
  }

  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );

  // Bazaya real sorğu: materialların sayı
  const { count, error } = await supabase
    .from("materials")
    .select("id", { count: "exact", head: true });

  if (error) return NextResponse.json({ ok: false, error: error.message }, { status: 500 });
  return NextResponse.json({ ok: true, materials: count, at: new Date().toISOString() });
}
